#!/usr/bin/env python3
"""
NBA Line Evaluator - ML-Powered Player Prop Analysis
=====================================================
Evaluates player prop lines using Random Forest or Neural Network models.
Scrapes live data for injuries, schedules, and historical performance.

Usage:
    python nba_evaluator.py --player "Nikola Jokic" --stat PTS --line 26.5
    python nba_evaluator.py --player "LeBron James" --stat PRA --line 45.5 --model neural
    python nba_evaluator.py --interactive
"""

import argparse
import json
import os
import pickle
import sys
import time
import warnings
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from bs4 import BeautifulSoup

# NBA API
from nba_api.stats.endpoints import (
    playergamelog,
    leaguegamefinder,
    commonplayerinfo,
    teamgamelog,
    scoreboardv2,
    leaguedashplayerstats,
    playerdashboardbygeneralsplits,
)
from nba_api.stats.static import players, teams

# ML Libraries
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score, TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib

# Neural Network (TensorFlow/Keras)
try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

warnings.filterwarnings("ignore")

# === CONFIGURATION ===
DATA_DIR = Path("./data")
MODEL_DIR = Path("./models")
HISTORY_DIR = Path("./history")

for d in [DATA_DIR, MODEL_DIR, HISTORY_DIR]:
    d.mkdir(exist_ok=True)

# Team name mappings
TEAM_ABBREV_TO_NAME = {
    'ATL': 'Atlanta Hawks', 'BOS': 'Boston Celtics', 'BKN': 'Brooklyn Nets',
    'CHA': 'Charlotte Hornets', 'CHI': 'Chicago Bulls', 'CLE': 'Cleveland Cavaliers',
    'DAL': 'Dallas Mavericks', 'DEN': 'Denver Nuggets', 'DET': 'Detroit Pistons',
    'GSW': 'Golden State Warriors', 'HOU': 'Houston Rockets', 'IND': 'Indiana Pacers',
    'LAC': 'LA Clippers', 'LAL': 'Los Angeles Lakers', 'MEM': 'Memphis Grizzlies',
    'MIA': 'Miami Heat', 'MIL': 'Milwaukee Bucks', 'MIN': 'Minnesota Timberwolves',
    'NOP': 'New Orleans Pelicans', 'NYK': 'New York Knicks', 'OKC': 'Oklahoma City Thunder',
    'ORL': 'Orlando Magic', 'PHI': 'Philadelphia 76ers', 'PHX': 'Phoenix Suns',
    'POR': 'Portland Trail Blazers', 'SAC': 'Sacramento Kings', 'SAS': 'San Antonio Spurs',
    'TOR': 'Toronto Raptors', 'UTA': 'Utah Jazz', 'WAS': 'Washington Wizards'
}

TEAM_NAME_TO_ABBREV = {v: k for k, v in TEAM_ABBREV_TO_NAME.items()}


class NBADataScraper:
    """Handles all data collection from NBA API and web scraping"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get_player_info(self, player_name):
        """Get player ID and team info"""
        print(f"🔍 Looking up player: {player_name}")
        p_info = players.find_players_by_full_name(player_name)
        if not p_info:
            # Try partial match
            all_players = players.get_players()
            matches = [p for p in all_players if player_name.lower() in p['full_name'].lower()]
            if matches:
                p_info = [matches[0]]
            else:
                return None
        
        player_id = p_info[0]['id']
        player_name = p_info[0]['full_name']
        
        try:
            common_info = commonplayerinfo.CommonPlayerInfo(player_id=player_id)
            time.sleep(0.5)  # Rate limiting
            info_df = common_info.get_data_frames()[0]
            team_id = info_df['TEAM_ID'].values[0]
            team_abbrev = info_df['TEAM_ABBREVIATION'].values[0]
            team_name = info_df['TEAM_NAME'].values[0]
            
            return {
                'player_id': player_id,
                'player_name': player_name,
                'team_id': team_id,
                'team_abbrev': team_abbrev,
                'team_name': team_name
            }
        except Exception as e:
            print(f"⚠️ Error getting player info: {e}")
            return {'player_id': player_id, 'player_name': player_name}
    
    def get_todays_games(self):
        """Get today's NBA games"""
        print("📅 Fetching today's schedule...")
        try:
            scoreboard = scoreboardv2.ScoreboardV2()
            time.sleep(0.5)
            games = scoreboard.get_data_frames()[0]
            return games
        except Exception as e:
            print(f"⚠️ Error fetching games: {e}")
            return pd.DataFrame()
    
    def get_player_next_game(self, player_info):
        """Find the player's next game"""
        print(f"📆 Finding next game for {player_info['player_name']}...")
        try:
            team_id = player_info.get('team_id')
            if not team_id:
                return None
            
            gamefinder = leaguegamefinder.LeagueGameFinder(
                team_id_nullable=team_id,
                season_nullable='2024-25',
                season_type_nullable='Regular Season'
            )
            time.sleep(0.5)
            games = gamefinder.get_data_frames()[0]
            games['GAME_DATE'] = pd.to_datetime(games['GAME_DATE'])
            
            today = datetime.now().date()
            # Get most recent games (API returns past games)
            recent = games.sort_values('GAME_DATE', ascending=False).head(1)
            
            if recent.empty:
                return None
            
            game = recent.iloc[0]
            matchup = game['MATCHUP']
            is_home = 1 if 'vs.' in matchup else 0
            opp_abbrev = matchup.split(' ')[-1]
            
            return {
                'matchup': matchup,
                'game_date': game['GAME_DATE'],
                'is_home': is_home,
                'opponent': opp_abbrev,
                'opponent_name': TEAM_ABBREV_TO_NAME.get(opp_abbrev, opp_abbrev)
            }
        except Exception as e:
            print(f"⚠️ Error finding next game: {e}")
            return None
    
    def get_player_game_log(self, player_id, seasons=None):
        """Get player's game log for specified seasons"""
        if seasons is None:
            seasons = ['2024-25', '2023-24', '2022-23']
        
        all_games = []
        for season in seasons:
            try:
                print(f"📊 Fetching {season} game log...")
                log = playergamelog.PlayerGameLog(
                    player_id=player_id,
                    season=season
                )
                time.sleep(0.6)
                df = log.get_data_frames()[0]
                df['SEASON'] = season
                all_games.append(df)
            except Exception as e:
                print(f"⚠️ Could not fetch {season}: {e}")
        
        if all_games:
            return pd.concat(all_games, ignore_index=True)
        return pd.DataFrame()
    
    def get_injury_report(self):
        """Scrape current NBA injury report"""
        print("🏥 Fetching injury report...")
        injuries = {}
        
        # Try multiple sources
        sources = [
            "https://www.cbssports.com/nba/injuries/",
            "https://www.espn.com/nba/injuries",
        ]
        
        for url in sources:
            try:
                resp = self.session.get(url, timeout=10)
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                # Parse injury data (structure varies by site)
                # This is a simplified version - real implementation would need
                # site-specific parsing
                text = soup.get_text().lower()
                
                for abbrev, name in TEAM_ABBREV_TO_NAME.items():
                    team_name_lower = name.lower()
                    # Count "out" mentions near team name (rough heuristic)
                    injuries[abbrev] = {
                        'out': text.count(f"{team_name_lower}") // 10,  # Rough estimate
                        'questionable': 0,
                        'players': []
                    }
                
                return injuries
            except Exception as e:
                continue
        
        # Return empty if all sources fail
        return {abbrev: {'out': 0, 'questionable': 0, 'players': []} 
                for abbrev in TEAM_ABBREV_TO_NAME}
    
    def get_vs_team_stats(self, player_id, opponent_abbrev):
        """Get player's historical stats against specific opponent"""
        print(f"📈 Analyzing performance vs {opponent_abbrev}...")
        try:
            # Get multi-season game log
            all_games = self.get_player_game_log(player_id)
            
            if all_games.empty:
                return None
            
            # Filter for games against opponent
            vs_games = all_games[all_games['MATCHUP'].str.contains(opponent_abbrev)]
            
            if vs_games.empty:
                return None
            
            return {
                'games': len(vs_games),
                'avg_pts': vs_games['PTS'].mean(),
                'avg_reb': vs_games['REB'].mean(),
                'avg_ast': vs_games['AST'].mean(),
                'avg_min': vs_games['MIN'].apply(lambda x: float(str(x).split(':')[0]) if ':' in str(x) else float(x)).mean(),
                'pts_std': vs_games['PTS'].std(),
                'reb_std': vs_games['REB'].std(),
                'ast_std': vs_games['AST'].std(),
            }
        except Exception as e:
            print(f"⚠️ Error getting vs stats: {e}")
            return None


class FeatureEngineer:
    """Creates features for ML models"""
    
    @staticmethod
    def create_features(game_log, player_info=None, game_info=None, injuries=None):
        """Create comprehensive feature set from game log"""
        df = game_log.copy()
        df = df.sort_values('GAME_DATE')
        
        # Parse minutes
        df['MIN_NUMERIC'] = df['MIN'].apply(
            lambda x: float(str(x).split(':')[0]) + float(str(x).split(':')[1])/60 
            if ':' in str(x) else float(x) if pd.notna(x) else 0
        )
        
        # Home/Away indicator
        df['IS_HOME'] = df['MATCHUP'].apply(lambda x: 1 if 'vs.' in str(x) else 0)
        
        # Extract opponent
        df['OPPONENT'] = df['MATCHUP'].apply(lambda x: str(x).split(' ')[-1])
        
        # Rolling averages (multiple windows)
        for stat in ['PTS', 'REB', 'AST', 'MIN_NUMERIC', 'FGA', 'FG_PCT', 'FTA']:
            if stat in df.columns:
                df[f'ROLL_5_{stat}'] = df[stat].rolling(5, min_periods=1).mean().shift(1)
                df[f'ROLL_10_{stat}'] = df[stat].rolling(10, min_periods=1).mean().shift(1)
                df[f'ROLL_20_{stat}'] = df[stat].rolling(20, min_periods=1).mean().shift(1)
                df[f'STD_10_{stat}'] = df[stat].rolling(10, min_periods=1).std().shift(1)
        
        # Combined stats
        df['PRA'] = df['PTS'] + df['REB'] + df['AST']
        df['ROLL_5_PRA'] = df['PRA'].rolling(5, min_periods=1).mean().shift(1)
        df['ROLL_10_PRA'] = df['PRA'].rolling(10, min_periods=1).mean().shift(1)
        
        # Trend (recent vs longer term)
        df['PTS_TREND'] = df['ROLL_5_PTS'] - df['ROLL_20_PTS']
        df['REB_TREND'] = df['ROLL_5_REB'] - df['ROLL_20_REB']
        df['AST_TREND'] = df['ROLL_5_AST'] - df['ROLL_20_AST']
        
        # Days rest (if we have date info)
        df['GAME_DATE'] = pd.to_datetime(df['GAME_DATE'])
        df['DAYS_REST'] = df['GAME_DATE'].diff().dt.days.fillna(3)
        df['DAYS_REST'] = df['DAYS_REST'].clip(0, 7)  # Cap at 7
        
        # Back-to-back indicator
        df['B2B'] = (df['DAYS_REST'] == 1).astype(int)
        
        # Game number in season
        df['GAME_NUM'] = range(1, len(df) + 1)
        
        # Win/Loss momentum
        df['WL_NUM'] = df['WL'].apply(lambda x: 1 if x == 'W' else 0)
        df['WIN_STREAK'] = df['WL_NUM'].rolling(5, min_periods=1).sum().shift(1)
        
        return df
    
    @staticmethod
    def get_prediction_features(df, is_home, opponent, injuries_team=0, injuries_opp=0):
        """Get feature vector for prediction"""
        latest = df.iloc[-1]
        
        features = {
            'IS_HOME': is_home,
            'ROLL_5_PTS': latest.get('ROLL_5_PTS', 0),
            'ROLL_10_PTS': latest.get('ROLL_10_PTS', 0),
            'ROLL_5_REB': latest.get('ROLL_5_REB', 0),
            'ROLL_10_REB': latest.get('ROLL_10_REB', 0),
            'ROLL_5_AST': latest.get('ROLL_5_AST', 0),
            'ROLL_10_AST': latest.get('ROLL_10_AST', 0),
            'ROLL_5_MIN_NUMERIC': latest.get('ROLL_5_MIN_NUMERIC', 30),
            'ROLL_10_MIN_NUMERIC': latest.get('ROLL_10_MIN_NUMERIC', 30),
            'STD_10_PTS': latest.get('STD_10_PTS', 5),
            'STD_10_REB': latest.get('STD_10_REB', 2),
            'STD_10_AST': latest.get('STD_10_AST', 2),
            'PTS_TREND': latest.get('PTS_TREND', 0),
            'REB_TREND': latest.get('REB_TREND', 0),
            'AST_TREND': latest.get('AST_TREND', 0),
            'DAYS_REST': 2,  # Default assumption
            'B2B': 0,
            'WIN_STREAK': latest.get('WIN_STREAK', 2.5),
            'INJURIES_TEAM': injuries_team,
            'INJURIES_OPP': injuries_opp,
        }
        
        return pd.DataFrame([features])


class MLPredictor:
    """Machine Learning prediction models"""
    
    def __init__(self, model_type='random_forest'):
        self.model_type = model_type
        self.models = {}
        self.scalers = {}
        self.feature_names = None
        self.training_history = []
    
    def _create_model(self, stat):
        """Create a new model instance"""
        if self.model_type == 'random_forest':
            return RandomForestRegressor(
                n_estimators=200,
                max_depth=10,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                n_jobs=-1
            )
        elif self.model_type == 'gradient_boost':
            return GradientBoostingRegressor(
                n_estimators=150,
                max_depth=5,
                learning_rate=0.1,
                random_state=42
            )
        elif self.model_type == 'neural' and TF_AVAILABLE:
            return self._create_neural_network()
        else:
            return RandomForestRegressor(n_estimators=100, random_state=42)
    
    def _create_neural_network(self):
        """Create neural network model"""
        model = keras.Sequential([
            layers.Dense(64, activation='relu', input_shape=(None,)),
            layers.Dropout(0.2),
            layers.Dense(32, activation='relu'),
            layers.Dropout(0.1),
            layers.Dense(16, activation='relu'),
            layers.Dense(1)
        ])
        model.compile(optimizer='adam', loss='mse', metrics=['mae'])
        return model
    
    def train(self, df, stats=['PTS', 'REB', 'AST']):
        """Train models for specified stats"""
        feature_cols = [
            'IS_HOME', 'ROLL_5_PTS', 'ROLL_10_PTS', 'ROLL_5_REB', 'ROLL_10_REB',
            'ROLL_5_AST', 'ROLL_10_AST', 'ROLL_5_MIN_NUMERIC', 'ROLL_10_MIN_NUMERIC',
            'STD_10_PTS', 'STD_10_REB', 'STD_10_AST',
            'PTS_TREND', 'REB_TREND', 'AST_TREND',
            'DAYS_REST', 'B2B', 'WIN_STREAK'
        ]
        
        # Filter to available features
        available_features = [f for f in feature_cols if f in df.columns]
        self.feature_names = available_features
        
        # Prepare data
        df_clean = df.dropna(subset=available_features + stats)
        
        if len(df_clean) < 20:
            print("⚠️ Insufficient data for training (need at least 20 games)")
            return False
        
        X = df_clean[available_features].values
        
        # Scale features
        self.scalers['features'] = StandardScaler()
        X_scaled = self.scalers['features'].fit_transform(X)
        
        print(f"\n🤖 Training {self.model_type} models on {len(df_clean)} games...")
        
        for stat in stats:
            y = df_clean[stat].values
            
            model = self._create_model(stat)
            
            if self.model_type == 'neural' and TF_AVAILABLE:
                # Neural network training
                model.fit(X_scaled, y, epochs=50, batch_size=16, verbose=0,
                         validation_split=0.2)
            else:
                # Sklearn model training with cross-validation
                tscv = TimeSeriesSplit(n_splits=5)
                scores = cross_val_score(model, X_scaled, y, cv=tscv, 
                                        scoring='neg_mean_absolute_error')
                print(f"  {stat}: CV MAE = {-scores.mean():.2f} (±{scores.std():.2f})")
                model.fit(X_scaled, y)
            
            self.models[stat] = model
        
        # Train PRA model
        if all(s in df_clean.columns for s in ['PTS', 'REB', 'AST']):
            y_pra = df_clean['PTS'] + df_clean['REB'] + df_clean['AST']
            model_pra = self._create_model('PRA')
            if self.model_type == 'neural' and TF_AVAILABLE:
                model_pra.fit(X_scaled, y_pra.values, epochs=50, batch_size=16, verbose=0)
            else:
                model_pra.fit(X_scaled, y_pra.values)
            self.models['PRA'] = model_pra
        
        return True
    
    def predict(self, features_df):
        """Make predictions for all trained stats"""
        if not self.models:
            return {}
        
        # Ensure features match training
        X = features_df[self.feature_names].values
        X_scaled = self.scalers['features'].transform(X)
        
        predictions = {}
        for stat, model in self.models.items():
            if self.model_type == 'neural' and TF_AVAILABLE:
                pred = model.predict(X_scaled, verbose=0)[0][0]
            else:
                pred = model.predict(X_scaled)[0]
            predictions[stat] = pred
        
        return predictions
    
    def get_confidence(self, df, stat, prediction):
        """Calculate confidence interval based on historical variance"""
        if stat in df.columns:
            std = df[stat].std()
            recent_std = df[stat].tail(10).std()
            # Use weighted average of overall and recent variance
            combined_std = 0.4 * std + 0.6 * recent_std
            return {
                'low': prediction - 1.5 * combined_std,
                'high': prediction + 1.5 * combined_std,
                'confidence': min(95, max(60, 100 - combined_std * 3))
            }
        return {'low': prediction * 0.8, 'high': prediction * 1.2, 'confidence': 70}
    
    def save(self, player_name):
        """Save model to disk"""
        filename = MODEL_DIR / f"{player_name.replace(' ', '_')}_model.pkl"
        data = {
            'models': self.models if self.model_type != 'neural' else None,
            'scalers': self.scalers,
            'feature_names': self.feature_names,
            'model_type': self.model_type,
            'training_history': self.training_history
        }
        
        if self.model_type == 'neural' and TF_AVAILABLE:
            # Save neural networks separately
            for stat, model in self.models.items():
                model.save(MODEL_DIR / f"{player_name.replace(' ', '_')}_{stat}_nn")
        
        with open(filename, 'wb') as f:
            pickle.dump(data, f)
        print(f"💾 Model saved to {filename}")
    
    def load(self, player_name):
        """Load model from disk"""
        filename = MODEL_DIR / f"{player_name.replace(' ', '_')}_model.pkl"
        if not filename.exists():
            return False
        
        with open(filename, 'rb') as f:
            data = pickle.load(f)
        
        self.scalers = data['scalers']
        self.feature_names = data['feature_names']
        self.model_type = data['model_type']
        self.training_history = data.get('training_history', [])
        
        if data['models']:
            self.models = data['models']
        elif self.model_type == 'neural' and TF_AVAILABLE:
            for stat in ['PTS', 'REB', 'AST', 'PRA']:
                nn_path = MODEL_DIR / f"{player_name.replace(' ', '_')}_{stat}_nn"
                if nn_path.exists():
                    self.models[stat] = keras.models.load_model(nn_path)
        
        print(f"📂 Loaded model from {filename}")
        return True


class LineEvaluator:
    """Evaluates betting lines against predictions"""
    
    def __init__(self):
        self.history = []
    
    def evaluate(self, prediction, line, stat, confidence_info=None):
        """Evaluate a betting line against prediction"""
        diff = prediction - line
        diff_pct = (diff / line) * 100
        
        # Determine recommendation
        if abs(diff_pct) < 3:
            recommendation = "LEAN OVER" if diff > 0 else "LEAN UNDER"
            strength = "SLIGHT"
        elif abs(diff_pct) < 8:
            recommendation = "OVER" if diff > 0 else "UNDER"
            strength = "MODERATE"
        else:
            recommendation = "STRONG OVER" if diff > 0 else "STRONG UNDER"
            strength = "HIGH"
        
        result = {
            'stat': stat,
            'line': line,
            'prediction': prediction,
            'difference': diff,
            'diff_pct': diff_pct,
            'recommendation': recommendation,
            'strength': strength,
        }
        
        if confidence_info:
            result['confidence'] = confidence_info['confidence']
            result['range_low'] = confidence_info['low']
            result['range_high'] = confidence_info['high']
            
            # Calculate probability of hitting over
            if confidence_info['high'] != confidence_info['low']:
                range_size = confidence_info['high'] - confidence_info['low']
                position = (line - confidence_info['low']) / range_size
                prob_over = max(0, min(100, (1 - position) * 100))
                result['prob_over'] = prob_over
        
        return result
    
    def log_prediction(self, player_name, evaluation, actual=None):
        """Log prediction for tracking accuracy"""
        entry = {
            'timestamp': datetime.now().isoformat(),
            'player': player_name,
            **evaluation
        }
        if actual is not None:
            entry['actual'] = actual
            entry['hit'] = (actual > evaluation['line']) == ('OVER' in evaluation['recommendation'])
        
        self.history.append(entry)
        
        # Save to file
        history_file = HISTORY_DIR / "predictions.json"
        try:
            if history_file.exists():
                with open(history_file, 'r') as f:
                    all_history = json.load(f)
            else:
                all_history = []
            all_history.append(entry)
            with open(history_file, 'w') as f:
                json.dump(all_history, f, indent=2)
        except Exception as e:
            print(f"⚠️ Could not save prediction history: {e}")


def print_banner():
    """Print application banner"""
    print("""
╔═══════════════════════════════════════════════════════════════════╗
║                    🏀 NBA LINE EVALUATOR 🏀                       ║
║              ML-Powered Player Prop Analysis                      ║
╚═══════════════════════════════════════════════════════════════════╝
    """)


def print_results(player_name, game_info, predictions, evaluations, vs_stats=None):
    """Print formatted results"""
    print("\n" + "=" * 60)
    print(f"  📊 ANALYSIS: {player_name.upper()}")
    print("=" * 60)
    
    if game_info:
        print(f"  🎮 Matchup: {game_info.get('matchup', 'N/A')}")
        print(f"  📍 Location: {'HOME' if game_info.get('is_home') else 'AWAY'}")
        print(f"  🆚 Opponent: {game_info.get('opponent_name', 'N/A')}")
    
    if vs_stats:
        print(f"\n  📈 vs {game_info.get('opponent', 'OPP')} History ({vs_stats['games']} games):")
        print(f"      Avg: {vs_stats['avg_pts']:.1f} PTS | {vs_stats['avg_reb']:.1f} REB | {vs_stats['avg_ast']:.1f} AST")
    
    print("\n" + "-" * 60)
    print("  🤖 ML PREDICTIONS:")
    print("-" * 60)
    
    for stat, pred in predictions.items():
        print(f"      {stat}: {pred:.1f}")
    
    if evaluations:
        print("\n" + "-" * 60)
        print("  📋 LINE EVALUATIONS:")
        print("-" * 60)
        
        for eval_result in evaluations:
            stat = eval_result['stat']
            icon = "🟢" if "OVER" in eval_result['recommendation'] else "🔴"
            
            print(f"\n  {icon} {stat} Line: {eval_result['line']}")
            print(f"      Prediction: {eval_result['prediction']:.1f} ({eval_result['diff_pct']:+.1f}%)")
            print(f"      ➤ {eval_result['recommendation']} ({eval_result['strength']} confidence)")
            
            if 'prob_over' in eval_result:
                print(f"      Prob Over: {eval_result['prob_over']:.0f}%")
            if 'range_low' in eval_result:
                print(f"      Range: {eval_result['range_low']:.1f} - {eval_result['range_high']:.1f}")
    
    print("\n" + "=" * 60)


def interactive_mode():
    """Run in interactive mode"""
    print_banner()
    
    scraper = NBADataScraper()
    evaluator = LineEvaluator()
    
    while True:
        print("\n📝 Enter player name (or 'quit' to exit):")
        player_input = input(">>> ").strip()
        
        if player_input.lower() in ['quit', 'exit', 'q']:
            print("👋 Goodbye!")
            break
        
        if not player_input:
            continue
        
        # Get player info
        player_info = scraper.get_player_info(player_input)
        if not player_info:
            print(f"❌ Player '{player_input}' not found. Try again.")
            continue
        
        player_name = player_info['player_name']
        print(f"✅ Found: {player_name}")
        
        # Get game info
        game_info = scraper.get_player_next_game(player_info)
        
        # Get game log and create features
        game_log = scraper.get_player_game_log(player_info['player_id'])
        if game_log.empty:
            print("❌ No game data available for this player.")
            continue
        
        # Feature engineering
        df = FeatureEngineer.create_features(game_log)
        
        # Get vs team stats
        vs_stats = None
        if game_info:
            vs_stats = scraper.get_vs_team_stats(
                player_info['player_id'], 
                game_info.get('opponent', '')
            )
        
        # Model selection
        print("\n🤖 Select model type:")
        print("  1. Random Forest (default)")
        print("  2. Gradient Boosting")
        if TF_AVAILABLE:
            print("  3. Neural Network")
        
        model_choice = input(">>> ").strip()
        model_type = {
            '1': 'random_forest',
            '2': 'gradient_boost',
            '3': 'neural' if TF_AVAILABLE else 'random_forest'
        }.get(model_choice, 'random_forest')
        
        # Initialize and train model
        predictor = MLPredictor(model_type=model_type)
        
        # Try to load existing model
        if not predictor.load(player_name):
            if not predictor.train(df):
                print("❌ Could not train model.")
                continue
            predictor.save(player_name)
        
        # Make predictions
        is_home = game_info.get('is_home', 0) if game_info else 0
        opponent = game_info.get('opponent', '') if game_info else ''
        
        features_df = FeatureEngineer.get_prediction_features(df, is_home, opponent)
        predictions = predictor.predict(features_df)
        
        # Get lines to evaluate
        evaluations = []
        print("\n📊 Enter lines to evaluate (or press Enter to skip):")
        for stat in ['PTS', 'REB', 'AST', 'PRA']:
            if stat in predictions:
                line_input = input(f"  {stat} line (prediction: {predictions[stat]:.1f}): ").strip()
                if line_input:
                    try:
                        line = float(line_input)
                        confidence_info = predictor.get_confidence(df, stat, predictions[stat])
                        eval_result = evaluator.evaluate(predictions[stat], line, stat, confidence_info)
                        evaluations.append(eval_result)
                        evaluator.log_prediction(player_name, eval_result)
                    except ValueError:
                        print(f"  ⚠️ Invalid number, skipping {stat}")
        
        # Print results
        print_results(player_name, game_info, predictions, evaluations, vs_stats)
        
        # Ask about saving
        print("\n💾 Save updated model? (y/n)")
        if input(">>> ").strip().lower() == 'y':
            predictor.train(df)  # Retrain with any new data
            predictor.save(player_name)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='NBA Line Evaluator - ML-Powered Player Prop Analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --player "Nikola Jokic" --stat PTS --line 26.5
  %(prog)s --player "LeBron James" --stat PRA --line 45.5 --model neural
  %(prog)s --interactive
  %(prog)s --player "Stephen Curry" --all-stats --pts-line 28.5 --reb-line 5.5 --ast-line 6.5
        """
    )
    
    parser.add_argument('--player', '-p', type=str, help='Player name')
    parser.add_argument('--stat', '-s', type=str, choices=['PTS', 'REB', 'AST', 'PRA'],
                       help='Stat to predict')
    parser.add_argument('--line', '-l', type=float, help='Betting line to evaluate')
    parser.add_argument('--model', '-m', type=str, default='random_forest',
                       choices=['random_forest', 'gradient_boost', 'neural'],
                       help='ML model type')
    parser.add_argument('--interactive', '-i', action='store_true',
                       help='Run in interactive mode')
    parser.add_argument('--all-stats', action='store_true',
                       help='Predict all stats')
    parser.add_argument('--pts-line', type=float, help='Points line')
    parser.add_argument('--reb-line', type=float, help='Rebounds line')
    parser.add_argument('--ast-line', type=float, help='Assists line')
    parser.add_argument('--pra-line', type=float, help='PRA (PTS+REB+AST) line')
    parser.add_argument('--retrain', action='store_true',
                       help='Force retrain model even if saved version exists')
    
    args = parser.parse_args()
    
    if args.interactive or (not args.player):
        interactive_mode()
        return
    
    print_banner()
    
    # Initialize components
    scraper = NBADataScraper()
    evaluator = LineEvaluator()
    
    # Get player info
    player_info = scraper.get_player_info(args.player)
    if not player_info:
        print(f"❌ Player '{args.player}' not found.")
        sys.exit(1)
    
    player_name = player_info['player_name']
    
    # Get game info
    game_info = scraper.get_player_next_game(player_info)
    
    # Get game log
    game_log = scraper.get_player_game_log(player_info['player_id'])
    if game_log.empty:
        print("❌ No game data available.")
        sys.exit(1)
    
    # Feature engineering
    df = FeatureEngineer.create_features(game_log)
    
    # Get vs team stats
    vs_stats = None
    if game_info:
        vs_stats = scraper.get_vs_team_stats(
            player_info['player_id'],
            game_info.get('opponent', '')
        )
    
    # Initialize model
    model_type = args.model
    if model_type == 'neural' and not TF_AVAILABLE:
        print("⚠️ TensorFlow not available, using Random Forest")
        model_type = 'random_forest'
    
    predictor = MLPredictor(model_type=model_type)
    
    # Load or train model
    if not args.retrain and predictor.load(player_name):
        pass  # Model loaded successfully
    else:
        if not predictor.train(df):
            print("❌ Could not train model.")
            sys.exit(1)
        predictor.save(player_name)
    
    # Make predictions
    is_home = game_info.get('is_home', 0) if game_info else 0
    opponent = game_info.get('opponent', '') if game_info else ''
    
    features_df = FeatureEngineer.get_prediction_features(df, is_home, opponent)
    predictions = predictor.predict(features_df)
    
    # Evaluate lines
    evaluations = []
    lines = {
        'PTS': args.pts_line or (args.line if args.stat == 'PTS' else None),
        'REB': args.reb_line or (args.line if args.stat == 'REB' else None),
        'AST': args.ast_line or (args.line if args.stat == 'AST' else None),
        'PRA': args.pra_line or (args.line if args.stat == 'PRA' else None),
    }
    
    for stat, line in lines.items():
        if line and stat in predictions:
            confidence_info = predictor.get_confidence(df, stat, predictions[stat])
            eval_result = evaluator.evaluate(predictions[stat], line, stat, confidence_info)
            evaluations.append(eval_result)
            evaluator.log_prediction(player_name, eval_result)
    
    # Print results
    print_results(player_name, game_info, predictions, evaluations, vs_stats)


if __name__ == "__main__":
    main()
